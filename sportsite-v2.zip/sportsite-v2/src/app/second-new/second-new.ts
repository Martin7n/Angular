import { Component } from '@angular/core';

@Component({
  selector: 'app-second-new',
  standalone: true,
  imports: [],
  templateUrl: './second-new.html',
  styleUrl: './second-new.css'
})
export class SecondNew {

}
