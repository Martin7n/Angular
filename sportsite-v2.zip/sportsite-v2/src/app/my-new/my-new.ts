import { Component } from '@angular/core';

@Component({
  selector: 'app-my-new',
  imports: [],
  templateUrl: './my-new.html',
  styleUrl: './my-new.css'
})
export class MyNew {

}
